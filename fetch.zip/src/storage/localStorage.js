import { tasks, setTasks } from "../state/tasksState";

// ======================================
// GUARDAR TAREAS
// ======================================

export function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// ======================================
// CARGAR TAREAS
// ======================================

export function loadTasks() {
  const storedTasks = localStorage.getItem("tasks");

  if (storedTasks) {
    setTasks(JSON.parse(storedTasks));
  }
}
