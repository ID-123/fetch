// Mostrar mensajes dinámicos
export function showMessage(text, type) {
  message.textContent = text;

  // Color según tipo
  if (type === "error") {
    message.style.color = "red";
  } else {
    message.style.color = "green";
  }

  // Limpiar mensaje después de 3 segundos
  setTimeout(() => {
    message.textContent = "";
  }, 3000);
}

export function showLoading(text) {
  loading.textContent = text;
}
  