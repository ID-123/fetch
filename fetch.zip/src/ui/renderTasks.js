import { tasks, currentFilter, searchTerm } from "../state/tasksState";
import { saveTasks } from "../storage/localStorage";
import { deleteTask, updateTask, toggleTaskCompleted } from "../api/tasksApi";
import { updateStats } from "./stats";

// REFERENCIAS
const taskList = document.getElementById("taskList");

const selectAll = document.getElementById("selectAll");

const completeSelectedBtn = document.getElementById("completeSelectedBtn");

// ACTUALIZAR BOTÓN COMPLETAR
export function updateCompleteButton() {
  // Obtener seleccionadas
  const selectedTasks = tasks.filter((task) => {
    return task.selected;
  });

  // Si no hay seleccionadas
  if (selectedTasks.length === 0) {
    completeSelectedBtn.textContent = "Completar seleccionadas";

    return;
  }

  // Verificar si todas están completas
  const allCompleted = selectedTasks.every((task) => {
    return task.completed;
  });

  // Cambiar texto dinámicamente
  if (allCompleted) {
    completeSelectedBtn.textContent = "Desmarcar completadas";
  } else {
    completeSelectedBtn.textContent = "Completar seleccionadas";
  }
}

// RENDERIZADO
export function renderTasks() {
  // Limpiar lista
  taskList.innerHTML = "";

  // Organiza por filtro
  let filteredTasks = tasks;

  // FILTRO COMPLETADAS
  if (currentFilter === "completed") {
    filteredTasks = tasks.filter((task) => {
      return task.completed;
    });
  }

  // FILTRO PENDIENTES
  if (currentFilter === "pending") {
    filteredTasks = tasks.filter((task) => {
      return !task.completed;
    });
  }

  // FILTRO DE BÚSQUEDA
  if (searchTerm !== "") {
    filteredTasks = filteredTasks.filter((task) => {
      return task.text.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }

  // Conteo
  updateStats();

  // Estado vacío
  if (tasks.length === 0) {
    const emptyMessage = document.createElement("p");

    emptyMessage.textContent = "No hay tareas todavía.";

    taskList.appendChild(emptyMessage);

    return;
  }

  // Recorrer tareas
  filteredTasks.forEach((task) => {
    // Elemento li
    const li = document.createElement("li");

    // Contenedor izquierdo
    const leftContainer = document.createElement("div");

    leftContainer.classList.add("left-container");

    // Contenedor derecho
    const rightContainer = document.createElement("div");

    rightContainer.classList.add("right-container");

    // CHECKBOX
    const checkbox = document.createElement("input");

    checkbox.type = "checkbox";

    // Estado actual
    checkbox.checked = task.selected;

    // Evento cambio
    checkbox.addEventListener("change", function () {
      task.selected = checkbox.checked;

      // Verificar si todas están seleccionadas
      const allSelected = tasks.every((task) => {
        return task.selected;
      });

      // Actualizar checkbox global
      selectAll.checked = allSelected;

      saveTasks();

      updateCompleteButton();
    });

    // Agregar checkbox
    leftContainer.appendChild(checkbox);

    // Contenedor del texto
    const taskSpan = document.createElement("span");
    const priorityBadge = document.createElement("span");

    priorityBadge.classList.add("priority-badge");

    // ======================================
    // PRIORIDADES
    // ======================================

    // PRIORIDAD ALTA
    if (task.priority === "high") {
      priorityBadge.textContent = "🔴 Alta";

      priorityBadge.classList.add("priority-high");
    }

    // PRIORIDAD MEDIA
    if (task.priority === "medium") {
      priorityBadge.textContent = "🟡 Media";

      priorityBadge.classList.add("priority-medium");
    }

    // PRIORIDAD BAJA
    if (task.priority === "low") {
      priorityBadge.textContent = "🟢 Baja";

      priorityBadge.classList.add("priority-low");
    }

    // Añade contenido de la tarea
    taskSpan.textContent = task.text;

    // Tarea completada
    if (task.completed) {
      taskSpan.classList.add("completed-task");
    }

    // Agregar nodo de tarea
    leftContainer.appendChild(taskSpan);
    leftContainer.appendChild(priorityBadge);

    // ======================================
    // BOTÓN EDITAR
    // ======================================

    const editButton = document.createElement("button");

    editButton.classList.add("edit-btn");

    editButton.textContent = "Editar";

    editButton.addEventListener("click", function () {
      // NUEVO TEXTO
      const newText = prompt("Editar tarea:", task.text);

      // Canceló prompt
      if (newText === null) {
        return;
      }

      // Validar vacío
      if (newText.trim() === "") {
        showMessage("La tarea no puede estar vacía", "error");

        return;
      }

      // VALIDAR DUPLICADOS
      const taskExists = tasks.some((currentTask) => {
        return (
          currentTask.id !== task.id &&
          currentTask.text.toLowerCase().trim() === newText.toLowerCase().trim()
        );
      });

      // Existe duplicado
      if (taskExists) {
        showMessage("Ya existe una tarea con ese nombre", "error");

        return;
      }

      // NUEVA PRIORIDAD
      const newPriority = prompt(
        "Nueva prioridad: low, medium o high",
        task.priority,
      );

      // Canceló prioridad
      if (newPriority === null) {
        return;
      }

      // Validar prioridad
      const validPriorities = ["low", "medium", "high"];

      if (!validPriorities.includes(newPriority.toLowerCase().trim())) {
        showMessage("Prioridad inválida", "error");

        return;
      }

      // ACTUALIZAR
      updateTask(task.id, newText.trim(), newPriority.toLowerCase().trim());
    });

    // Agregar botón editar
    rightContainer.appendChild(editButton);

    // ======================================
    // BOTÓN COMPLETAR
    // ======================================

    const completeButton = document.createElement("button");

    completeButton.classList.add("complete-btn");

    // Texto dinámico
    if (task.completed) {
      completeButton.textContent = "Deshacer";
    } else {
      completeButton.textContent = "Completar";
    }

    completeButton.addEventListener("click", function () {
      toggleTaskCompleted(task.id);
    });

    // Agregar botón
    rightContainer.appendChild(completeButton);

    // ======================================
    // BOTÓN ELIMINAR
    // ======================================

    const deleteButton = document.createElement("button");

    deleteButton.classList.add("delete-btn");

    deleteButton.textContent = "Eliminar";

    deleteButton.addEventListener("click", function () {
      // Confirmación
      const confirmDelete = confirm("¿Seguro que deseas eliminar esta tarea?");

      if (confirmDelete) {
        deleteTask(task.id);
      }
    });

    // Agregar botón eliminar
    rightContainer.appendChild(deleteButton);

    // Agregar li al ul
    li.appendChild(leftContainer);
    li.appendChild(rightContainer);
    taskList.appendChild(li);
  });

  updateCompleteButton();
}
