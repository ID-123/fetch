import { tasks } from "../state/tasksState";

// Variables Globales
const totalTasks = document.getElementById("totalTasks");

const pendingTasks = document.getElementById("pendingTasks");

const completedTasks = document.getElementById("completedTasks");

const selectedTasks = document.getElementById("selectedTasks");

export function updateStats() {

  // TOTAL
  totalTasks.textContent = `Total: ${tasks.length}`;

  // PENDIENTES
  const pendingCount = tasks.filter((task) => {
    return !task.completed;
  }).length;

  pendingTasks.textContent = `Pendientes: ${pendingCount}`;

  // COMPLETADAS
  const completedCount = tasks.filter((task) => {
    return task.completed;
  }).length;

  completedTasks.textContent = `Completadas: ${completedCount}`;

  // SELECCIONADAS
  const selectedCount = tasks.filter((task) => {
    return task.selected;
  }).length;

  selectedTasks.textContent = `Seleccionadas: ${selectedCount}`;
}
