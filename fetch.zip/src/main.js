import "./style.css";
import { showMessage, showLoading } from "./ui/messages";
import { tasks, setTasks, setFilter, setSearchTerm } from "./state/tasksState";
import { saveTasks, loadTasks } from "./storage/localStorage";
import { renderTasks, updateCompleteButton } from "./ui/renderTasks";
import {
  fetchTasks,
  addTask,
  deleteSelectedTasks,
  completeSelectedTasks,
} from "./api/tasksApi";

// ======================================
// CONFIGURACIÓN
// ======================================

// URL base de la API
const API_URL = "http://localhost:3000/tasks";

// ======================================
// VARIABLES GLOBALES
// ======================================

const taskForm = document.getElementById("taskForm");

const deleteSelectedBtn = document.getElementById("deleteSelectedBtn");

const selectAll = document.getElementById("selectAll");

const completeSelectedBtn = document.getElementById("completeSelectedBtn");

const taskInput = document.getElementById("taskInput");

const prioritySelect = document.getElementById("prioritySelect");

const taskList = document.getElementById("taskList");

const message = document.getElementById("message");

const loading = document.getElementById("loading");

const filterAll = document.getElementById("filterAll");

const filterPending = document.getElementById("filterPending");

const filterCompleted = document.getElementById("filterCompleted");

const searchInput = document.getElementById("searchInput");

const syncBtn = document.getElementById("syncButton");

// ======================================
// EVENTOS
// ======================================

// Evento submit
taskForm.addEventListener("submit", async function (event) {
  // Evitar recarga
  event.preventDefault();

  // Obtener texto
  const taskText = taskInput.value.trim();

  // Validar input
  if (taskText === "") {
    showMessage("La tarea no puede estar vacía", "error");

    return;
  }

  // Verificar duplicados
  const taskExists = tasks.some((task) => {
    return task.text.toLowerCase().trim() === taskText.toLowerCase().trim();
  });

  // Validar duplicado
  if (taskExists) {
    showMessage("La tarea ya existe", "error");

    return;
  }

  // Agregar tarea
  await addTask(taskText, prioritySelect.value);

  // Limpiar input
  taskInput.value = "";
});

// SELECCIONAR TODAS
selectAll.addEventListener("change", function () {
  // Cambiar estado de todas
  setTasks(
    tasks.map((task) => {
      return {
        ...task,

        selected: selectAll.checked,
      };
    }),
  );

  // Guardar
  saveTasks();

  // Renderizar
  renderTasks();

  updateCompleteButton();
});

// COMPLETAR SELECCIONADAS
completeSelectedBtn.addEventListener("click", completeSelectedTasks);

// ELIMINAR SELECCIONADAS
deleteSelectedBtn.addEventListener("click", deleteSelectedTasks);

// FILTROS
filterAll.addEventListener("click", () => {
  setFilter("all");

  renderTasks();
});

filterPending.addEventListener("click", () => {
  setFilter("pending");

  renderTasks();
});

filterCompleted.addEventListener("click", () => {
  setFilter("completed");

  renderTasks();
});

// BUSCADOR
searchInput.addEventListener("input", () => {
  setSearchTerm(searchInput.value);

  renderTasks();
});

// SINCRONIZAR CON API
syncBtn.addEventListener("click", () => {
  fetchTasks();

  showMessage("Sincronizando con API...", "success");
});

// ======================================
// INICIALIZACIÓN
// ======================================

// Obtener tareas desde API
fetchTasks();
