import { tasks, setTasks } from "../state/tasksState";

import { saveTasks, loadTasks } from "../storage/localStorage";

import { renderTasks } from "../ui/renderTasks";

import { showMessage, showLoading } from "../ui/messages";

// CONFIGURACIÓN API
const API_URL = "http://localhost:3000/tasks";

// ======================================
// API
// ======================================

// Obtener tareas
export async function fetchTasks() {
  showLoading("Cargando tareas...");

  try {
    const response = await fetch(API_URL);

    // Validar respuesta HTTP
    if (!response.ok) {
      throw new Error("Error al obtener tareas");
    }

    const data = await response.json();

    // Guardar tareas
    setTasks(data);

    // Persistencia local
    saveTasks();

    // Renderizar
    renderTasks();

    showLoading("");

    console.log("Tareas obtenidas:", data);
  } catch (error) {
    console.error(error);
    showLoading("");

    // Si falla API usar Local Storage
    loadTasks();

    showMessage("Servidor no disponible. Cargando datos locales.", "error");
  }
}

// ======================================
// CRUD
// ======================================

// CREAR TAREA
export async function addTask(taskText, priority) {
  // Nueva tarea
  const task = {
    text: taskText,
    priority: priority,
    selected: false,
    completed: false,
  };

  try {
    const response = await fetch(API_URL, {
      method: "POST",

      headers: {
        "Content-Type": "application/json",
      },

      body: JSON.stringify(task),
    });

    // Validar respuesta
    if (!response.ok) {
      throw new Error("Error al crear tarea");
    }

    // Convertir respuesta
    const newTask = await response.json();

    // Actualizar array
    tasks.push(newTask);

    // Guardar localmente
    saveTasks();

    // Renderizar
    renderTasks();

    console.log("Tarea creada:", newTask);

    showMessage("Tarea agregada correctamente", "success");
  } catch (error) {
    console.error(error);

    showMessage("Error al agregar tarea", "error");
  }
}

// ELIMINAR TAREA
export async function deleteTask(taskId) {
  try {
    const response = await fetch(`${API_URL}/${taskId}`, {
      method: "DELETE",
    });

    // Validar respuesta
    if (!response.ok) {
      throw new Error("Error al eliminar tarea");
    }

    // Filtrar tareas
    setTasks(
      tasks.filter((task) => {
        return task.id !== taskId;
      }),
    );

    // Guardar
    saveTasks();

    // Renderizar
    renderTasks();

    // Reiniciar selector global
    selectAll.checked = false;

    console.log("Tarea eliminada:", taskId);

    showMessage("Tarea eliminada correctamente", "success");
  } catch (error) {
    console.error(error);

    showMessage("Error al eliminar tarea", "error");
  }
}

// COMPLETAR TAREAS SELECCIONADAS
export async function completeSelectedTasks() {
  try {
    // Obtener seleccionadas
    const selectedTasks = tasks.filter((task) => {
      return task.selected;
    });

    // Validar selección
    if (selectedTasks.length === 0) {
      showMessage("No hay tareas seleccionadas", "error");

      return;
    }

    // Actualizar una por una
    for (const task of selectedTasks) {
      const updatedTask = {
        ...task,

        completed: !task.completed,
      };

      // PUT
      await fetch(`${API_URL}/${task.id}`, {
        method: "PUT",

        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify(updatedTask),
      });
    }

    // Actualizar array local
    setTasks(
      tasks.map((task) => {
        if (task.selected) {
          return {
            ...task,

            completed: !task.completed,

            selected: false,
          };
        }

        return task;
      }),
    );

    // Guardar
    saveTasks();

    // Renderizar
    renderTasks();

    // Reset global
    selectAll.checked = false;

    showMessage("Tareas completadas", "success");
  } catch (error) {
    console.error(error);

    showMessage("Error al completar tareas", "error");
  }
}

// ELIMINAR TAREAS SELECCIONADAS
export async function deleteSelectedTasks() {
  try {
    // Obtener tareas seleccionadas
    const selectedTasks = tasks.filter((task) => {
      return task.selected;
    });

    // Validar selección
    if (selectedTasks.length === 0) {
      showMessage("No hay tareas seleccionadas", "error");

      return;
    }

    // Confirmación
    const confirmDelete = confirm(`¿Eliminar ${selectedTasks.length} tareas?`);

    if (!confirmDelete) {
      return;
    }

    // Eliminar una por una desde API
    for (const task of selectedTasks) {
      await fetch(`${API_URL}/${task.id}`, {
        method: "DELETE",
      });
    }

    // Filtrar tareas restantes
    setTasks(
      tasks.filter((task) => {
        return !task.selected;
      }),
    );

    // Guardar
    saveTasks();

    // Renderizar
    renderTasks();

    // Reiniciar selector global
    selectAll.checked = false;

    showMessage("Tareas eliminadas correctamente", "success");
  } catch (error) {
    console.error(error);

    showMessage("Error al eliminar tareas", "error");
  }
}

// ACTUALIZAR TAREA
export async function updateTask(taskId, newText, newPriority) {
  try {
    // Buscar tarea actual
    const currentTask = tasks.find((task) => {
      return task.id === taskId;
    });

    // Crear tarea actualizada
    const updatedTask = {
      ...currentTask,
      text: newText,
      priority: newPriority,
    };

    const response = await fetch(`${API_URL}/${taskId}`, {
      method: "PUT",

      headers: {
        "Content-Type": "application/json",
      },

      body: JSON.stringify(updatedTask),
    });

    // Validar respuesta
    if (!response.ok) {
      throw new Error("Error al actualizar tarea");
    }

    // Convertir respuesta
    const data = await response.json();

    // Actualizar array
    setTasks(
      tasks.map((task) => {
        if (task.id === taskId) {
          return data;
        }

        return task;
      }),
    );

    // Guardar
    saveTasks();

    // Renderizar
    renderTasks();

    console.log("Tarea actualizada:", data);

    showMessage("Tarea actualizada correctamente", "success");
  } catch (error) {
    console.error(error);

    showMessage("Error al actualizar tarea", "error");
  }
}

// TOGGLE COMPLETAR TAREA
export async function toggleTaskCompleted(taskId) {
  try {
    // Buscar tarea
    const currentTask = tasks.find((task) => {
      return task.id === taskId;
    });

    // Invertir estado
    const updatedTask = {
      ...currentTask,

      completed: !currentTask.completed,
    };

    // PUT
    const response = await fetch(`${API_URL}/${taskId}`, {
      method: "PUT",

      headers: {
        "Content-Type": "application/json",
      },

      body: JSON.stringify(updatedTask),
    });

    // Validar
    if (!response.ok) {
      throw new Error("Error al actualizar tarea");
    }

    // Convertir respuesta
    const data = await response.json();

    // Actualizar array
    setTasks(
      tasks.map((task) => {
        if (task.id === taskId) {
          return data;
        }

        return task;
      }),
    );

    // Guardar
    saveTasks();

    // Renderizar
    renderTasks();

    showMessage("Estado actualizado", "success");
  } catch (error) {
    console.error(error);

    showMessage("Error al actualizar estado", "error");
  }
}
