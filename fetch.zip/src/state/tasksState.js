// Array global de tareas
export let tasks = [];

export let currentFilter = "all";

export let searchTerm = "";

// Setter
export function setTasks(newTask) {
  tasks = newTask;
}

export function setFilter(filter) {
  currentFilter = filter;
}

export function setSearchTerm(term) {
  searchTerm = term;
}
